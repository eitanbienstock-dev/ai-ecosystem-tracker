import { supabase } from "@/lib/supabase";
import { formatDate } from "@/lib/format";
import { markStackImplicationReviewed } from "@/lib/actions";

export const dynamic = "force-dynamic";

type DigestEntry = {
  id: string;
  source: string;
  report_title: string;
  report_url: string | null;
  published_date: string | null;
  scanned_at: string;
  summary: string | null;
  key_takeaways: string | null;
  relevant_tickers: string[] | null;
  sentiment: "bullish" | "bearish" | "neutral" | null;
  tickers_requiring_update: string[] | null;
  stack_implication: boolean;
  stack_implication_note: string | null;
  stack_reviewed_at: string | null;
};

function SentimentArrow({ sentiment }: { sentiment: string | null }) {
  if (sentiment === "bullish") return <span className="text-rise" title="Bullish">▲</span>;
  if (sentiment === "bearish") return <span className="text-fall" title="Bearish">▼</span>;
  return null;
}

export default async function ResearchDigestPage({
  searchParams,
}: {
  searchParams: { filter?: string };
}) {
  const { data, error } = await supabase
    .from("research_digest")
    .select("*")
    .order("scanned_at", { ascending: false });

  if (error) {
    return (
      <div className="rounded border border-fall/40 bg-fall/10 p-4 text-sm text-fall">
        Could not load research digest: {error.message}
      </div>
    );
  }

  const all = (data ?? []) as DigestEntry[];
  const filterStack = searchParams?.filter === "stack";
  const entries = filterStack
    ? all.filter((e) => e.stack_implication && !e.stack_reviewed_at)
    : all;

  const pendingStackCount = all.filter(
    (e) => e.stack_implication && !e.stack_reviewed_at
  ).length;

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-[#e7e8ea]">Research digest</h1>
        <p className="text-sm text-muted">
          Findings from periodic scans of major bank and institutional AI research. Scans run on
          request, not on a fixed schedule. Sorted by scan date, most recent first. A ticker
          outlined in amber means this finding may require updating that company and recalculating
          its score.
        </p>
      </div>

      {/* Stack implication banner */}
      {pendingStackCount > 0 && (
        <div className="mb-6 flex items-center justify-between rounded border border-[#D98E3F]/40 bg-[#D98E3F]/8 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs font-bold text-[#D98E3F]">⬡ AI STACK</span>
            <span className="text-sm text-[#e7e8ea]">
              {pendingStackCount} digest {pendingStackCount === 1 ? "entry" : "entries"} flagged with
              a stack implication pending review
            </span>
          </div>
          <a
            href={filterStack ? "/research" : "/research?filter=stack"}
            className="font-mono text-xs text-[#D98E3F] hover:underline"
          >
            {filterStack ? "Show all" : "Show pending →"}
          </a>
        </div>
      )}

      {/* Filter pill when active */}
      {filterStack && pendingStackCount === 0 && (
        <div className="mb-6 rounded border border-line bg-panel px-4 py-3 text-sm text-muted">
          No pending stack implications.{" "}
          <a href="/research" className="text-signal hover:underline">
            Show all entries
          </a>
        </div>
      )}

      {entries.length === 0 ? (
        <div className="rounded border border-dashed border-line py-10 text-center">
          <p className="text-sm text-muted">No scans logged yet.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {entries.map((e) => {
            const pendingReview = e.stack_implication && !e.stack_reviewed_at;
            return (
              <div
                key={e.id}
                className={`rounded border bg-panel p-5 ${
                  pendingReview ? "border-[#D98E3F]/50" : "border-line"
                }`}
              >
                <div className="mb-2 flex items-baseline justify-between">
                  <div className="flex items-center gap-2 flex-wrap">
                    <SentimentArrow sentiment={e.sentiment} />
                    <span className="badge bg-panelhi text-[#e7e8ea]">{e.source}</span>
                    <span className="font-medium text-[#e7e8ea]">{e.report_title}</span>
                    {e.stack_implication && (
                      <span
                        className={`font-mono text-[9px] font-bold tracking-wider px-1.5 py-0.5 rounded border ${
                          pendingReview
                            ? "border-[#D98E3F]/60 bg-[#D98E3F]/10 text-[#D98E3F]"
                            : "border-line bg-panelhi text-muted"
                        }`}
                      >
                        ⬡ STACK
                      </span>
                    )}
                  </div>
                  <span className="font-mono text-xs text-muted shrink-0 ml-4">
                    {e.published_date ? formatDate(e.published_date) : "date unknown"} &middot;{" "}
                    scanned {formatDate(e.scanned_at)}
                  </span>
                </div>

                {e.summary && <p className="text-sm text-[#cfd1d5]">{e.summary}</p>}
                {e.key_takeaways && (
                  <p className="mt-2 text-sm text-signal">Relevant to us: {e.key_takeaways}</p>
                )}

                {/* Stack implication note */}
                {e.stack_implication && e.stack_implication_note && (
                  <div className="mt-3 rounded border border-[#D98E3F]/30 bg-[#D98E3F]/6 px-3 py-2">
                    <span className="font-mono text-[9px] font-bold tracking-wider text-[#D98E3F]">
                      STACK IMPLICATION
                    </span>
                    <p className="mt-0.5 text-sm text-[#e7e8ea]">{e.stack_implication_note}</p>
                  </div>
                )}

                {/* Reviewed status / mark reviewed */}
                {e.stack_implication && (
                  <div className="mt-3">
                    {e.stack_reviewed_at ? (
                      <span className="font-mono text-[10px] text-muted">
                        Stack reviewed {formatDate(e.stack_reviewed_at)}
                      </span>
                    ) : (
                      <form
                        action={markStackImplicationReviewed.bind(null, e.id)}
                      >
                        <button
                          type="submit"
                          className="font-mono text-[10px] text-[#D98E3F] hover:underline border border-[#D98E3F]/40 rounded px-2 py-0.5 hover:bg-[#D98E3F]/10 transition-colors"
                        >
                          Mark stack reviewed →
                        </button>
                      </form>
                    )}
                  </div>
                )}

                {(e.relevant_tickers ?? []).length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {(e.relevant_tickers ?? []).map((t) => {
                      const needsUpdate = (e.tickers_requiring_update ?? []).includes(t);
                      return (
                        <span
                          key={t}
                          className={`badge border bg-panelhi text-muted ${
                            needsUpdate
                              ? "border-signal ring-1 ring-signal text-signal"
                              : "border-line"
                          }`}
                          title={
                            needsUpdate
                              ? "May require updating this company and recalculating its score"
                              : undefined
                          }
                        >
                          {t}
                        </span>
                      );
                    })}
                  </div>
                )}

                {e.report_url && (
                  <a
                    href={e.report_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-block text-xs text-signal hover:underline"
                  >
                    Source →
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
